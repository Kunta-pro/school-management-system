document.getElementById('login-form').addEventListener('submit', function(event) {

    event.preventDefault();

    const userId = document.getElementById('user-id').value;

    const password = document.getElementById('password').value;

    // Sample credentials

    const credentials = {

        parent: { id: 'parent123', password: 'password123' },

        student: { id: 'student123', password: 'password123' },

        teacher: { id: 'teacher123', password: 'password123' }

    };

    if (userId === credentials.parent.id && password === credentials.parent.password) {

        showDashboard('parent-dashboard');

    } else if (userId === credentials.student.id && password === credentials.student.password) {

        showDashboard('student-dashboard');

    } else if (userId === credentials.teacher.id && password === credentials.teacher.password) {

        showDashboard('teacher-dashboard');

    } else {

        alert('Invalid credentials');

    }

});

function showDashboard(dashboardId) {

    document.querySelectorAll('.dashboard').forEach(dashboard => {

        dashboard.classList.add('hidden');

    });

    document.getElementById(dashboardId).classList.remove('hidden');

}

document.getElementById('toggle-notes').addEventListener('click', function() {

    const notes = document.getElementById('notes');

    notes.classList.toggle('hidden');

});

document.getElementById('upload-marks').addEventListener('click', function() {

    document.getElementById('marks-popup').classList.toggle('hidden');

});

document.getElementById('add-row').addEventListener('click', function() {

    const table = document.getElementById('marks-table');

    const newRow = table.insertRow();

    const cell1 = newRow.insertCell(0);

    const cell2 = newRow.insertCell(1);

    cell1.innerHTML = '<input type="text" placeholder="Student ID">';

    cell2.innerHTML = '<input type="text" placeholder="Marks">';

});

document.getElementById('download-csv').addEventListener('click', function() {

    // Add functionality to download CSV

    alert('Download CSV functionality not implemented yet.');

});

document.getElementById('upload-to-codex').addEventListener('click', function() {

    // Add functionality to upload to Codex

    alert('Upload to Codex functionality not implemented yet.');

});

// Logout functionality

document.querySelectorAll('#logout').forEach(button => {

    button.addEventListener('click', function() {

        document.querySelectorAll('.dashboard').forEach(dashboard => {

            dashboard.classList.add('hidden');

        });

        document.getElementById('login').classList.remove('hidden');

    });

});

// Forgot Password functionality

document.getElementById('forgot-password').addEventListener('click', function() {

   

// Forgot Password functionality

document.getElementById('forgot-password').addEventListener('click', function() {

    alert('Forgot Password feature is not implemented yet.');

});

// Add the rest of the JavaScript code here as needed

